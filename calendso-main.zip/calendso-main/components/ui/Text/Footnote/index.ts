import Footnote from "./Footnote";

export default Footnote;
