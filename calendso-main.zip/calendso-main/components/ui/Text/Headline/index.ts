import Headline from "./Headline";

export default Headline;
