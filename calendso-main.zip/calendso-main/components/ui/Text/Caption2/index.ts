import Caption2 from "./Caption2";

export default Caption2;
