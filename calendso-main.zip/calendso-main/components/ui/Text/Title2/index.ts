import Title2 from "./Title2";

export default Title2;
