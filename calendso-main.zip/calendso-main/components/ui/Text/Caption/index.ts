import Caption from "./Caption";

export default Caption;
