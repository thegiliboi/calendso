import Subheadline from "./Subheadline";

export default Subheadline;
