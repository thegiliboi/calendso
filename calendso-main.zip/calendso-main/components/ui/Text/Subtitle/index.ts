import Subtitle from "./Subtitle";

export default Subtitle;
