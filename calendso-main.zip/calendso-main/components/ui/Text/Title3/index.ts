import Title3 from "./Title3";

export default Title3;
