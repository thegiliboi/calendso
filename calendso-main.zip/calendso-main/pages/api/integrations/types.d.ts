export type IntegrationOAuthCallbackState = {
  returnTo: string;
};
