export { default } from "@ee/pages/api/integrations/stripepayment/callback";
