export { default, config } from "@ee/pages/api/integrations/stripepayment/webhook";
