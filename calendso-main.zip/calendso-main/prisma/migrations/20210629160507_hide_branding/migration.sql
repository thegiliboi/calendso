-- AlterTable
ALTER TABLE "users" ADD COLUMN     "hideBranding" BOOLEAN NOT NULL DEFAULT false;
