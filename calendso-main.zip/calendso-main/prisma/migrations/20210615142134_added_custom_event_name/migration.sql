-- AlterTable
ALTER TABLE "EventType" ADD COLUMN     "eventName" TEXT;
