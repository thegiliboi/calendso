-- AlterTable
ALTER TABLE "users" ADD COLUMN     "bufferTime" INTEGER NOT NULL DEFAULT 0;
