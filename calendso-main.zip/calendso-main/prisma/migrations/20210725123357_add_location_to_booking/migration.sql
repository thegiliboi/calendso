-- AlterTable
ALTER TABLE "Booking" ADD COLUMN     "location" TEXT;
