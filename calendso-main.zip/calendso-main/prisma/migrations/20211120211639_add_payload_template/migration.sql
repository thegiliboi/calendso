-- AlterTable
ALTER TABLE "Webhook" ADD COLUMN     "payloadTemplate" TEXT;
