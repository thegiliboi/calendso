-- AlterTable
ALTER TABLE "EventType" ADD COLUMN     "disableGuests" BOOLEAN NOT NULL DEFAULT false;
