-- AlterTable
ALTER TABLE "EventType" ADD COLUMN     "minimumBookingNotice" INTEGER NOT NULL DEFAULT 120;
