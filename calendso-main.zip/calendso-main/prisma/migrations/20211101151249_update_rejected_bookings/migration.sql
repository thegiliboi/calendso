UPDATE "Booking" SET "status" = 'rejected' WHERE "rejected" = TRUE;
