-- AlterTable
ALTER TABLE "users" ADD COLUMN     "theme" TEXT;
