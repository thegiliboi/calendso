-- AlterTable
ALTER TABLE "BookingReference" ADD COLUMN     "meetingId" TEXT,
ADD COLUMN     "meetingPassword" TEXT,
ADD COLUMN     "meetingUrl" TEXT;
