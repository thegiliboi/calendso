-- AlterTable
ALTER TABLE "EventType" ADD COLUMN     "position" INTEGER NOT NULL DEFAULT 0;
