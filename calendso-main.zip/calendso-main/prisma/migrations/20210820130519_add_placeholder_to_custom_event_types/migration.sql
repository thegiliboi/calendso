-- AlterTable
ALTER TABLE "EventTypeCustomInput" ADD COLUMN     "placeholder" TEXT NOT NULL DEFAULT E'';
