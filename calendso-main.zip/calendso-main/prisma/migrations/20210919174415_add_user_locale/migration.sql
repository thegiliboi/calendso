-- AlterTable
ALTER TABLE "users" ADD COLUMN     "locale" TEXT;
