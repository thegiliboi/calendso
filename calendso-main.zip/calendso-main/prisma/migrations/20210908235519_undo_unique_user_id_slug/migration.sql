-- DropIndex
DROP INDEX "EventType.userId_slug_unique";
