-- AlterTable
ALTER TABLE "Team" ADD COLUMN     "slug" TEXT;
