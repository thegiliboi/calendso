export type SVGComponent = React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
